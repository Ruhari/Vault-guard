from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, FileResponse
from .forms import SignUpForm, SignInForm, AddEntryForm
from .models import Entry
import random
import string
import logging
from .ai_service import get_gemini_response
import json
from django.db import models
from django.contrib.auth.hashers import check_password
from django.contrib.auth import update_session_auth_hash
from django.core.files.storage import FileSystemStorage
import os
from datetime import datetime, timedelta
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from io import BytesIO

logger = logging.getLogger(__name__)

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        logger.info(f"Form data: {request.POST}")
        if form.is_valid():
            user = form.save()
            messages.success(request, "You have successfully signed up! Please sign in.")
            logger.info("User created successfully")
            return redirect('signin')
        else:
            logger.error(f"Form errors: {form.errors}")
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.capitalize()}: {error}")
    else:
        form = SignUpForm()
    return render(request, 'accounts/signup.html', {'form': form})

def signin(request):
    if request.method == 'POST':
        form = SignInForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, "You have successfully signed in!")
                return redirect('home')
            else:
                messages.error(request, "Invalid email or password.")
                logger.warning(f"Failed login attempt for email: {email}")
    else:
        form = SignInForm()
    return render(request, 'accounts/signin.html', {'form': form})

@login_required
def home(request):
    try:
        entries = Entry.objects.filter(user=request.user).order_by('-updated_at')
        return render(request, 'vault/home.html', {'entries': entries})
    except Exception as e:
        logger.error(f"Error fetching entries: {str(e)}")
        messages.error(request, "An error occurred while loading your entries.")
        return render(request, 'vault/home.html', {'entries': []})

@login_required
def add_entry(request):
    if request.method == 'POST':
        form = AddEntryForm(request.POST)
        if form.is_valid():
            try:
                entry = form.save(commit=False)
                entry.user = request.user
                entry.save()
                messages.success(request, "Entry added successfully!")
                return redirect('home')
            except Exception as e:
                logger.error(f"Error saving entry: {str(e)}")
                messages.error(request, "An error occurred while saving your entry.")
    else:
        form = AddEntryForm()
    return render(request, 'vault/add_entry.html', {'form': form})

@login_required
def edit_entry(request, entry_id):
    try:
        entry = get_object_or_404(Entry, id=entry_id, user=request.user)
        if request.method == 'POST':
            form = AddEntryForm(request.POST, instance=entry)
            if form.is_valid():
                form.save()
                messages.success(request, "Entry updated successfully!")
                return redirect('home')
        else:
            form = AddEntryForm(instance=entry)
        return render(request, 'vault/edit_entry.html', {'form': form, 'entry': entry})
    except Exception as e:
        logger.error(f"Error editing entry {entry_id}: {str(e)}")
        messages.error(request, "An error occurred while editing the entry.")
        return redirect('home')

@login_required
def delete_entry(request, entry_id):
    try:
        entry = get_object_or_404(Entry, id=entry_id, user=request.user)
        if request.method == 'POST':
            entry.delete()
            messages.success(request, "Entry deleted successfully.")
            return redirect('home')
        return redirect('edit_entry', entry_id=entry_id)
    except Exception as e:
        logger.error(f"Error deleting entry {entry_id}: {str(e)}")
        messages.error(request, "An error occurred while deleting the entry.")
        return redirect('home')

@login_required
def generator(request):
    return render(request, 'vault/generator.html')

@login_required
def generate_password(request):
    try:
        length = int(request.GET.get('length', 12))
        characters = string.ascii_letters + string.digits + string.punctuation
        password = ''.join(random.choice(characters) for i in range(length))
        return JsonResponse({'password': password})
    except Exception as e:
        logger.error(f"Error generating password: {str(e)}")
        return JsonResponse({'error': 'Failed to generate password'}, status=500)

@login_required
def ai_assistance(request):
    try:
        # Get chat history from session or initialize if not exists
        chat_history = request.session.get('gemini_chat_history', None)
        last_chat_time = request.session.get('last_chat_time', None)
        
        # Check if 1 hour has passed since last chat
        if last_chat_time:
            last_time = datetime.fromisoformat(last_chat_time)
            if datetime.now() - last_time > timedelta(hours=1):
                chat_history = None
                request.session['gemini_chat_history'] = None
                request.session['last_chat_time'] = None
                request.session.modified = True
        
        # Convert from JSON string if needed
        if isinstance(chat_history, str):
            try:
                chat_history = json.loads(chat_history)
            except json.JSONDecodeError:
                chat_history = None
        
        # Extract conversation for display
        conversation = []
        if chat_history:
            for i in range(0, len(chat_history), 2):
                if i+1 < len(chat_history):
                    user_message = chat_history[i]['parts'][0] if chat_history[i]['parts'] else ""
                    ai_message = chat_history[i+1]['parts'][0] if chat_history[i+1]['parts'] else ""
                    conversation.append({
                        'user': user_message,
                        'ai': ai_message
                    })
        
        context = {
            'conversation': conversation
        }
        return render(request, 'vault/ai_assistance.html', context)
    except Exception as e:
        logger.error(f"Error in AI assistance: {str(e)}")
        messages.error(request, "An error occurred while loading the AI assistant.")
        return render(request, 'vault/ai_assistance.html', {'conversation': []})

@login_required
def clear_chat_history(request):
    try:
        if request.is_ajax():
            if 'gemini_chat_history' in request.session:
                del request.session['gemini_chat_history']
                request.session.modified = True
            return JsonResponse({'status': 'success'})
        else:
            if 'gemini_chat_history' in request.session:
                del request.session['gemini_chat_history']
                request.session.modified = True
            return redirect('ai_assistance')
    except Exception as e:
        logger.error(f"Error clearing chat history: {str(e)}")
        if request.is_ajax():
            return JsonResponse({'error': 'Failed to clear chat history'}, status=500)
        return redirect('ai_assistance')

@login_required
def gemini_api(request):
    try:
        if request.method == 'POST':
            user_input = request.POST.get('user_input', '')
            
            # Get chat history from session
            chat_history = request.session.get('gemini_chat_history', None)
            
            # Convert from JSON string if needed
            if isinstance(chat_history, str):
                try:
                    chat_history = json.loads(chat_history)
                except json.JSONDecodeError:
                    chat_history = None
            
            if user_input:
                # Get response with history
                response, updated_history = get_gemini_response(user_input, chat_history)
                
                # Store updated history in session with timestamp
                request.session['gemini_chat_history'] = updated_history
                request.session['last_chat_time'] = datetime.now().isoformat()
                request.session.modified = True
                
                return JsonResponse({'response': response})
        
        return JsonResponse({'error': 'Invalid request'}, status=400)
    except Exception as e:
        logger.error(f"Error in Gemini API: {str(e)}")
        return JsonResponse({'error': 'An error occurred'}, status=500)

def user_logout(request):
    try:
        logout(request)
        messages.success(request, "You have been successfully logged out.")
        return redirect('signin')
    except Exception as e:
        logger.error(f"Error during logout: {str(e)}")
        messages.error(request, "An error occurred during logout.")
        return redirect('signin')

@login_required
def get_password_history(request, entry_id):
    try:
        entry = get_object_or_404(Entry, id=entry_id, user=request.user)
        # Implement password history logic here if needed
        return JsonResponse({'history': []})
    except Exception as e:
        logger.error(f"Error fetching password history: {str(e)}")
        return JsonResponse({'error': 'Failed to fetch password history'}, status=500)

@login_required
def search_entries(request):
    try:
        query = request.GET.get('q', '').strip()
        if query:
            entries = Entry.objects.filter(
                user=request.user
            ).filter(
                models.Q(title__icontains=query) |
                models.Q(account__icontains=query) |
                models.Q(username__icontains=query) |
                models.Q(website__icontains=query) |
                models.Q(notes__icontains=query)
            ).order_by('-updated_at')[:10]  # Limit to 10 results for better performance
            
            return JsonResponse({
                'entries': [{
                    'id': entry.id,
                    'title': entry.title,
                    'account': entry.account,
                    'username': entry.username,
                    'website': entry.website,
                    'updated_at': entry.updated_at.strftime('%Y-%m-%d %H:%M:%S')
                } for entry in entries]
            })
        return JsonResponse({'entries': []})
    except Exception as e:
        logger.error(f"Error searching entries: {str(e)}")
        return JsonResponse({'error': 'An error occurred while searching'}, status=500)

@login_required
def profile(request):
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'update_profile':
            name = request.POST.get('name')
            phone = request.POST.get('phone')
            backup_email = request.POST.get('backup_email')
            
            request.user.name = name
            request.user.save()
            
            profile = request.user.userprofile
            profile.phone = phone
            profile.backup_email = backup_email
            
            if 'avatar' in request.FILES:
                avatar = request.FILES['avatar']
                fs = FileSystemStorage(location='media/avatars')
                filename = fs.save(avatar.name, avatar)
                profile.avatar = f'avatars/{filename}'
            
            profile.save()
            messages.success(request, 'Profile updated successfully!')
            
        elif action == 'change_password':
            current_password = request.POST.get('current_password')
            new_password = request.POST.get('new_password')
            confirm_password = request.POST.get('confirm_password')
            
            if not check_password(current_password, request.user.password):
                messages.error(request, 'Current password is incorrect!')
            elif new_password != confirm_password:
                messages.error(request, 'New passwords do not match!')
            else:
                request.user.set_password(new_password)
                request.user.save()
                update_session_auth_hash(request, request.user)
                request.user.userprofile.last_password_change = datetime.now()
                request.user.userprofile.save()
                messages.success(request, 'Password changed successfully!')
    
    return render(request, 'vault/profile.html')

@login_required
def backup_vault(request):
    # Create a PDF backup of all entries
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    
    # Add title
    p.setFont("Helvetica-Bold", 16)
    p.drawString(50, 750, f"VaultGuard Backup - {datetime.now().strftime('%Y-%m-%d')}")
    
    # Add user info
    p.setFont("Helvetica", 12)
    p.drawString(50, 720, f"User: {request.user.email}")
    p.drawString(50, 700, f"Backup Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Add entries
    y = 650
    entries = Entry.objects.filter(user=request.user).order_by('-updated_at')
    
    for entry in entries:
        if y < 100:  # Start new page if near bottom
            p.showPage()
            y = 750
        
        p.setFont("Helvetica-Bold", 12)
        p.drawString(50, y, f"Title: {entry.title}")
        y -= 20
        p.setFont("Helvetica", 10)
        p.drawString(50, y, f"Account: {entry.account}")
        y -= 15
        p.drawString(50, y, f"Username: {entry.username}")
        y -= 15
        p.drawString(50, y, f"Password: {entry.password}")
        y -= 15
        if entry.website:
            p.drawString(50, y, f"Website: {entry.website}")
            y -= 15
        if entry.notes:
            p.drawString(50, y, f"Notes: {entry.notes}")
            y -= 15
        y -= 20  # Space between entries
    
    p.save()
    
    # FileResponse sets the Content-Disposition header so the browser presents the
    # option to save the file
    buffer.seek(0)
    response = FileResponse(buffer, as_attachment=True, filename='mybackup.pdf')
    return response

@login_required
def about(request):
    return render(request, 'vault/about.html')