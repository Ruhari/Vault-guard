from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup, name='signup'),
    path('signin/', views.signin, name='signin'),
    path('', views.home, name='home'),
    path('logout/', views.user_logout, name='logout'),
    path('search/', views.search_entries, name='search_entries'),
    path('profile/', views.profile, name='profile'),
    path('backup/', views.backup_vault, name='backup_vault'),
    path('about/', views.about, name='about'),
    path('entry/<int:entry_id>/history/', views.get_password_history, name='password_history'),
    path('generate_password/', views.generate_password, name='generate_password'),
    
    #sidebar
    path('generator/', views.generator, name='generator'),
    path('ai-assistance/', views.ai_assistance, name='ai_assistance'),
    path('clear-chat-history/', views.clear_chat_history, name='clear_chat_history'),
    
    # API endpoint for Gemini
    path('gemini-api/', views.gemini_api, name='gemini_api'),
    
    path('add/', views.add_entry, name='add_entry'),
    path('entry/<int:entry_id>/edit/', views.edit_entry, name='edit_entry'),
    path('entry/<int:entry_id>/delete/', views.delete_entry, name='delete_entry'),
]

