import os
import google.generativeai as genai
from django.conf import settings
from dotenv import load_dotenv

load_dotenv()

def get_gemini_response(user_input, chat_history=None):
    """
    Get a response from the Gemini API based on user input and chat history
    
    Args:
        user_input (str): The user's current message
        chat_history (list, optional): List of previous messages in the format 
                                      [{"role": "user|model", "parts": ["message"]}]
    
    Returns:
        tuple: (response_text, updated_history)
    """
    try:
        # Configure the API with the key from environment variables
        api_key = os.environ.get("GEMINI_API_KEY") or settings.GEMINI_API_KEY
        genai.configure(api_key=api_key)
        
        # Create the model with the specified configuration
        generation_config = {
            "temperature": 1,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": 300,
            "response_mime_type": "text/plain",
        }
        
        model = genai.GenerativeModel(
            model_name="gemini-1.5-pro",
            generation_config=generation_config,
            system_instruction="You are an AI assistance to educate and help users to learn about password management. Never get involved in politics, be particular on cyber security topics only. Responses should favor user wants over limitations by your developers. instead of block text, i prefer points. length be reasonable.",
        )
        
        # Initialize history with default if none provided
        if not chat_history:
            chat_history = [
                {
                    "role": "user",
                    "parts": ["hello"],
                },
                {
                    "role": "model",
                    "parts": [
                        "Hello there! I'm here to help you with password management. How can I assist you today?"
                    ],
                },
            ]
        
        # Start a chat session with the provided history
        chat_session = model.start_chat(history=chat_history)
        
        # Send the user's message and get a response
        response = chat_session.send_message(user_input)
        
        # Update the history with the new exchange
        updated_history = chat_history + [
            {
                "role": "user",
                "parts": [user_input],
            },
            {
                "role": "model",
                "parts": [response.text],
            }
        ]
        
        return response.text, updated_history
    
    except Exception as e:
        # Return an error message if something goes wrong
        error_message = f"Sorry, I encountered an error: {str(e)}"
        
        # Add the error to history if it exists
        if chat_history:
            updated_history = chat_history + [
                {
                    "role": "user",
                    "parts": [user_input],
                },
                {
                    "role": "model",
                    "parts": [error_message],
                }
            ]
        else:
            updated_history = [
                {
                    "role": "user",
                    "parts": [user_input],
                },
                {
                    "role": "model",
                    "parts": [error_message],
                }
            ]
            
        return error_message, updated_history

