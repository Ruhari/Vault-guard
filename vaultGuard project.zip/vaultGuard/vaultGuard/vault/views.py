from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import SignUpForm, SignInForm, AddEntryForm
from .models import Entry

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "You have successfully signed up!")
            return redirect('home')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.capitalize()}: {error}")
    else:
        form = SignUpForm()
    return render(request, 'vault/signup.html', {'form': form})

def signin(request):
    if request.method == 'POST':
        form = SignInForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('email')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, "You have successfully signed in!")
                return redirect('home')
            else:
                messages.error(request, "Invalid email or password.")
    else:
        form = SignInForm()
    return render(request, 'vault/signin.html', {'form': form})

@login_required
def home(request):
    entries = Entry.objects.filter(user=request.user)
    return render(request, 'vault/home.html', {'entries': entries})

@login_required
def add_entry(request):
    if request.method == 'POST':
        form = AddEntryForm(request.POST)
        if form.is_valid():
            entry = form.save(commit=False)
            entry.user = request.user
            entry.save()
            return redirect('home')
    else:
        form = AddEntryForm()
    return render(request, 'vault/add_entry.html', {'form': form})

@login_required
def edit_entry(request, entry_id):
    entry = Entry.objects.get(id=entry_id, user=request.user)
    if request.method == 'POST':
        form = AddEntryForm(request.POST, instance=entry)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = AddEntryForm(instance=entry)
    return render(request, 'vault/edit_entry.html', {'form': form, 'entry': entry})

def user_logout(request):
    logout(request)
    messages.success(request, "You have been successfully logged out.")
    return redirect('signin')

