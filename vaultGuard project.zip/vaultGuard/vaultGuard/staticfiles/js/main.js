function togglePassword(inputId, toggleId) {
const input = document.getElementById(inputId)
const toggle = document.getElementById(toggleId)

if (input.type === "password") {
    input.type = "text"
    toggle.textContent = "👁️‍🗨️"
} else {
    input.type = "password"
    toggle.textContent = "👁️"
}
}

function generatePassword() {
const length = 16
const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+"
let password = ""
for (let i = 0; i < length; i++) {
    password += charset.charAt(Math.floor(Math.random() * charset.length))
}
document.getElementById("password").value = password
}

/*
function to copy password to clipboard  
function copyPassword() {
    var copyText = document.getElementById("password");
    copyText.select();
    copyText.setSelectionRange(0, 99999); 
    document.execCommand("copy");
    alert("Password copied to clipboard: " + copyText.value);
}
*/