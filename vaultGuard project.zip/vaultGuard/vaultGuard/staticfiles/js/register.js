document.addEventListener("DOMContentLoaded", () => {
const form = document.getElementById("signupForm")
const passwordInput = document.getElementById("password")
const confirmPasswordInput = document.getElementById("confirmPassword")
const emailInput = document.getElementById("email")

// Password validation requirements
const requirements = {
    length: /.{8,}/,
    uppercase: /[A-Z]/,
    lowercase: /[a-z]/,
    number: /[0-9]/,
    special: /[!@#$%^&*(),.?":{}|<>]/,
}

// Email validation
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function validatePassword(password) {
    const results = {
    length: requirements.length.test(password),
    uppercase: requirements.uppercase.test(password),
    lowercase: requirements.lowercase.test(password),
    number: requirements.number.test(password),
    special: requirements.special.test(password),
    }

    // Update UI for each requirement
    Object.keys(results).forEach((req) => {
    const element = document.getElementById(`${req}Req`)
    if (results[req]) {
        element.classList.add("valid")
    } else {
        element.classList.remove("valid")
    }
    })

    return Object.values(results).every((result) => result === true)
}

function validateEmail(email) {
    return emailRegex.test(email)
}

// Real-time password validation
passwordInput.addEventListener("input", function () {
    validatePassword(this.value)
})

// Form submission handler
form.addEventListener("submit", async (e) => {
    e.preventDefault()

    const name = document.getElementById("name").value
    const email = emailInput.value
    const password = passwordInput.value
    const confirmPassword = confirmPasswordInput.value
    let isValid = true

    // Clear previous error messages
    document.querySelectorAll(".error-message").forEach((elem) => (elem.textContent = ""))

    // Validate name
    if (name.trim().length < 2) {
    document.getElementById("nameError").textContent = "Name must be at least 2 characters long"
    isValid = false
    }

    // Validate email
    if (!validateEmail(email)) {
    document.getElementById("emailError").textContent = "Please enter a valid email address"
    isValid = false
    }

    // Validate password
    if (!validatePassword(password)) {
    document.getElementById("passwordError").textContent = "Password does not meet all requirements"
    isValid = false
    }

    // Validate password confirmation
    if (password !== confirmPassword) {
    document.getElementById("confirmPasswordError").textContent = "Passwords do not match"
    isValid = false
    }

    if (isValid) {
    try {
        const formData = new FormData(form)
        const response = await fetch(form.action, {
        method: "POST",
        body: formData,
        headers: {
            "X-CSRFToken": document.querySelector("[name=csrfmiddlewaretoken]").value,
        },
        })

        if (response.ok) {
        window.location.href = "/home/" // Redirect to home page on success
        } else {
        const data = await response.json()
        // Display server-side validation errors
        if (data.errors) {
            Object.keys(data.errors).forEach((field) => {
            const errorElement = document.getElementById(`${field}Error`)
            if (errorElement) {
                errorElement.textContent = data.errors[field]
            }
            })
        }
        }
    } catch (error) {
        console.error("Error:", error)
        alert("An error occurred. Please try again.")
    }
    }
})
})

function togglePassword(inputId, toggleId) {
const input = document.getElementById(inputId)
const toggle = document.getElementById(toggleId)

if (input.type === "password") {
    input.type = "text"
    toggle.textContent = "👁️‍🗨️"
} else {
    input.type = "password"
    toggle.textContent = "👁️"
}
}

